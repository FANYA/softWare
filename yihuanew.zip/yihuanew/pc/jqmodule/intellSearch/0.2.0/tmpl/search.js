define("intellSearch/0.2.0/tmpl/search",[],function(require,exports,module) {

module.exports = function anonymous(it
/**/) {
var out='<div class="ly_search">  <div class="ly_search_row"> <div class="ly_search_inputgp" search-wapper> <input type="text" class="search_input" search-input placeholder="'+(it.placeholder)+'"> <div class="ly_search_gp" search-group="inputlist"></div> <div search-group="searchlabel"></div> </div> <label class="ly_search_btn" search-submit>'+(it.submitName)+'</label> </div></div>';return out;
}

});