define("intellSearch/0.1.0/tmpl/themeSearch",[],function(require,exports,module) {

module.exports = function anonymous(it
/**/) {
var out='<div class="theme_play ly_search"> <div class="ly_search_row"> <div class="ly_search_inputgp" search-wapper> <input type="text" search-input placeholder="'+(it.placeholder)+'"> <div class="ly_search_gp" search-group></div> <div class=\'theme-label\'> <a href=\'/dujia/theme/hunshaxiezhen29/\' target=\'_blank\'>婚纱写真</a> <a href=\'/dujia/theme/xialingying32/\' target=\'_blank\'>夏令营</a> <a href=\'/dujia/theme/zijia23/\' target=\'_blank\'>国际自驾</a> </div> </div> <label class="ly_search_btn" search-submit>'+(it.submitName)+'</label> </div></div>';return out;
}

});