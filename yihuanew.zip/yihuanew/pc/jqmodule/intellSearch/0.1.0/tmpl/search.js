define("intellSearch/0.1.0/tmpl/search",[],function(require,exports,module) {

module.exports = function anonymous(it
/**/) {
var out='﻿<div class="ly_search"> <div class="ly_search_row"> <div class="ly_search_inputgp" search-wapper> <input type="text" search-input placeholder="'+(it.placeholder)+'"> <div class="ly_search_gp" search-group></div> </div> <label class="ly_search_btn" search-submit>'+(it.submitName)+'</label> </div></div>';return out;
}

});