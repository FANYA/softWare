define("datepicker/0.2.0/tmpl/yearpanel",[],function(require,exports,module) {

module.exports = function anonymous(it
/**/) {
var out='<div class="year_panel"> <span class="yp_btn yp_btn_up"> <i class="ico sort-asc"></i> </span> <div class="yp_years">   </div> <span class="yp_btn yp_btn_down"> <i class="ico sort-desc"></i> </span></div>';return out;
}

});