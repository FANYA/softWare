define(function () { var dotTmpl = function anonymous(it
/**/) {
var out='<div class="calendar-range"> <div class="calendar dp-stardate"> </div> <div class="calendar dp-enddate"> </div></div>';return out;
}  ;return dotTmpl;});