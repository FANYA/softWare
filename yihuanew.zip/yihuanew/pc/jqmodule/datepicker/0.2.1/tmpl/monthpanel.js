define(function () { var dotTmpl = function anonymous(it
/**/) {
var out='<div class="month_panel"> ';for(var i=1;i<=12;i++){ out+=' <span class="month" data-value="'+(i)+'">'+(i)+'月</span> '; } out+='</div>';return out;
}  ;return dotTmpl;});