var Activity;
(function($){
    if (!Array.prototype.indexOf)
    {
      Array.prototype.indexOf = function(elt)
      {
        var len = this.length >>> 0;
        var from = Number(arguments[1]) || 0;
        from = (from < 0)
             ? Math.ceil(from)
             : Math.floor(from);
        if (from < 0)
          from += len;
        for (; from < len; from++)
        {
          if (from in this &&
              this[from] === elt)
            return from;
        }
        return -1;
      };
    }
    Activity = {
        extraStr: "",
        dataUrl: "http://www.ly.com/dujia/AjaxHelper/PrickGoldFingerHandler.ashx?action=GETTARENTORESOURSELIST&pageindex=1&pagesize=70&platForm=0&lists={ActivityId}&pid={CycleId}&IsSellOut={IsSellOut}",
        checkUrl: "http://www.ly.com/dujia/AjaxActivity.aspx?Type=GetEncryptionTemp&source={LineId},{ActivityId},{CycleId}",
        sceneryUrl: "http://www.ly.com/dujia/AjaxHelper/SingleProductHandler.ashx?action=GetSingleProductActUrl&id={LineId}&actId={ActivityId}&periodId={CycleId}",
        data: {},
        cfg: {
            ActivityId: "",
            CycleId: "",
            IsSellOut: 0,
            beforeRender: function(data){
                if(Activity._cfg.filter){
                    return this.filterData(data);
                }else{
                    this.data = data;
                    return data.data;
                }
            },
            afterRender: function(){

            }
        },
        filterData: function(data){
            var cfg = this._cfg,
                el = $(cfg.el),
                newData = {};
            var filterRule = [],
                filterElRule = {};
            el.each(function(i,n){
                var filterStr = n.getAttribute("data-filter");
                if(filterStr){
                    if(!filterRule){
                        filterRule = [];
                    }
                    //如果不包含，则放入数组
                    if(!~filterRule.indexOf(filterStr)){
                        filterRule.push(filterStr);
                    }
                    var _ruleItem = filterElRule[filterStr];
                    if(!_ruleItem){
                        _ruleItem = [];
                    }
                    _ruleItem.push(n);
                    filterElRule[filterStr] = _ruleItem;
                }
            });
            if(filterRule.length === 0){
                return data.data;
            }
            this.filterElRule = filterElRule;
            var filterRuleItem = filterRule;
            if(!filterRuleItem){
                console.log("对应容器的规则不存在!");
                return;
            }
            for(var i = 0, len = data.data.length -1; i<=len; i++){
                var item = data.data[i];
                for(var n = 0, nLen = filterRuleItem.length -1; n<=nLen; n++){
                    var filterItem = filterRuleItem[n],
                        filterObjItem = this.unparam(filterItem);
                    if(filterObjItem){
                        var flag = true;
                        for(var x in filterObjItem){
                            if(filterObjItem.hasOwnProperty(x) && item[x] != filterObjItem[x]){
                                flag = false;
                                break;
                            }
                        }
                        if(flag){
                            if(!newData[filterItem]){
                                newData[filterItem] = [];
                            }
                            newData[filterItem].push(item);
                            break;
                        }
                    }else{
                        alert("filter表达式不存在!");
                    }
                }
            }
            return newData;
        },
        init: function(cfg){
            var self = this,
                defaultCfg = self.cfg;
            var _cfg = self._cfg = $.extend(defaultCfg,cfg),
                param = _cfg.param;
            if(!param){
                console.log("param不存在");
                return;
            }
            var paramList = self.getParamData(param);
            if(paramList.length > 0){
                self.getOneData(paramList,function(){});
            }
            if(self.isInitEvent){
                return;
            }
            self.isInitEvent = true;
            if(!_cfg.clickEvent){
                self.initEvent();
            }else{
                _cfg.clickEvent.call(self,$(_cfg.el));
            }
        },
        unparam: function(str, sep, eq) {
            if (typeof str !== 'string' || !(str = $.trim(str))) {
                return {};
            }
            sep = sep || "&";
            eq = eq || "=";
            var ret = {},
                eqIndex,
                pairs = str.split(sep),
                key, val,
                i = 0,
                len = pairs.length;

            for (; i < len; ++i) {
                eqIndex = pairs[i].indexOf(eq);
                if (eqIndex === -1) {
                    key = pairs[i];
                    val = undefined;
                } else {
                    key = pairs[i].substring(0, eqIndex);
                    val = pairs[i].substring(eqIndex + 1);
                }
                if (key in ret) {
                    if (typeof (ret[key]) === "object") {
                        ret[key].push(val);
                    } else {
                        ret[key] = [ret[key], val];
                    }
                } else {
                    ret[key] = val;
                }
            }
            return ret;
        },
        getParamData: function(param){
            if(!(param &&$.isArray(param))){
                console.log("请求接口所需参数不存在!");
                return;
            }
            var paramList = [];
            for(var x = 0, len = param.length -1; x<=len; x++){
                var paramItem = param[x];
                for(var i in paramItem){
                    if(!paramItem.hasOwnProperty(i)){
                        continue;
                    }
                    var item = paramItem[i];
                    if(typeof item === "object"){
                        for(var n = 0; n<=item.length -1; n++){
                            paramList.push([i,item[n]]);
                        }
                    }
                }
            }
            return paramList;
        },
        getOneData: function(paramList,callback){
            var self = this;
            if(paramList.length){
                var paramItem = paramList.shift();
                var thisCfg = $.extend({},self._cfg);
                thisCfg.ActivityId = paramItem[0];
                thisCfg.CycleId = paramItem[1];
                self.getData(thisCfg,function(data){
                    if(data){
                        var arr = data.data,
                            selfArr = self.data.data||[];
                        self.data["data"] = selfArr.concat(arr);
                    }
                    self.getOneData(paramList,callback);
                });
            }else{
                var data = self.data,
                    retData = self._cfg.beforeRender && self._cfg.beforeRender.call(self,data);
                self.render(retData);
                self._cfg.afterRender && self._cfg.afterRender.call(self,retData);
                callback && callback.call(this);
            }
        },
        render: function(data){
            var self = this;
            if(self._cfg.filter){
                var ruleItem = self.filterElRule;
                for(var x in ruleItem){
                    self.renderHTML(data[x]||{},$(ruleItem[x]));
                }
            }else{
                self.renderHTML(data,$(self._cfg.el));
            }
        },
        renderHTML: function(data,context,tmplStr){
            if(!tmplStr){
                tmplStr = context.attr("data-tmpl");
            }
            if(!tmplStr){
                alert("没有配置data-tmpl");
                return;
            }
            var tmpl = $(tmplStr).html();
            var tpl = window.doT.template(tmpl);
            var html = tpl(data);
            context.empty().append(html);
            this.imgLazyLoad();
        },
        getData: function(cfg,callback){
            var self = this;
            var url = self.dataUrl.replace(/{(\w+)}/g,function($0,$1){
                if(cfg[$1] === undefined){
                    console.log("url对应的"+$1+"参数不存在!");
                }
                return cfg[$1]===undefined?"":cfg[$1];
            });
            $.ajax({
                url: url,
                dataType: "jsonp",
                jsonpCallback: "jsonp"+cfg.CycleId,
                success: function(data){
                    callback && callback.call(self,data);
                },
                error: function(err){
                    if(err){
                        console.error("接口有误:"+url);
                    }
                }
            });
        },
        setImageSize: function (url, size) {
            if (!url) {
                return null;
            }
            var defaultSize = "_600x300_00";
            if(size && size.indexOf("_") === -1){
                size = "_"+size+"_00";
            }
            var reg = /_[0-9]{2,3}x[0-9]{2,3}_[0-9]?[0-9]/;
            var regSize = /_[0-9]{2,3}x[0-9]{2,3}_[0-9]?[0-9]$/;
            if (reg.test(url) && regSize.test(size)) {
                return url.replace(reg, size);
            }

            if (reg.test(url)) {
                return url;
            }

            if (url.indexOf("upload.17u.com") > -1) {
                return url;
            } else if (!reg.test(url)) {
                return url.replace(/\.\w+$/,function($0){
                    return (size || defaultSize)+$0;
                });
            }
        },
        imgLazyLoad: function(){
            var self = this,
                cfg = self.cfg,
                parent = $(cfg.el).parent();
            if (this.isInit) {
                var imgList = parent.find("img").not("[data-img-loaded]");
                $(window).trigger("addElements",imgList);
            } else {
                parent.find("img").not("[data-img-loaded]").lazyload({
                    "data_attribute": "img"
                });
                this.isInit = true;
            }
        },
        initEvent: function(){
            var me = this,
                cfg = me.cfg,
                context = $(cfg.el);

            $(context).on("mousedown","a",function(e){
                if(e.which === 3){
                    return;
                }
                if(me.isClicking) {
                    return;
                }
                me.isClicking = true;
                me.encrypt(this,cfg.login, function(){
                    me.isClicking = false;
                });
                e.preventDefault();
            });
        },
        encryptScenery: function(el,callback){
            var self = this,
                checkUrl = self.sceneryUrl,
                url = checkUrl.replace(/{(\w+)}/g,function($0,$1){
                    var attr = el.getAttribute("data-"+$1)||self.cfg[$1];
                    if(!attr){
                        console.log($1+"对应的值不存在!");
                    }
                    return attr||"";
                });
            var newwindow = window.open();
            $.ajax({
                url: url,
                dataType: "jsonp",
                success: function(data){
                    if(data){
                        var extraStr = self.extraStr,
                            url = data.url + extraStr + self.getRefId();
                        callback.call(self);
                        newwindow.location.href = url;
                    }
                }
            });
        },
        encrypt: function(el,isLogin,callback){
            var self = this,
                ret = self.cfg.checkScenery && self.cfg.checkScenery.call(self,el);
            if(ret){
                self.encryptScenery(el,callback);
                return;
            }
            var checkUrl = self.checkUrl,
                url = checkUrl.replace(/{(\w+)}/g,function($0,$1){
                    var attr = el.getAttribute("data-"+$1)||self.cfg[$1];
                    if(!attr){
                        console.log($1+"对应的值不存在!");
                    }
                    return attr||"";
                });
            var newwindow = window.open(),
                href = el.getAttribute("href");
            $.ajax({
                url: url,
                dataType: "jsonp",
                success: function(data){
                    if(data){
                        var extraStr = self.extraStr,
                            url = href+"?ak="+encodeURIComponent(encodeURIComponent(data.key))+extraStr+self.getRefId()+"&selltype=4";
                        callback.call(self);
                        newwindow.location.href = url;
                    }
                }
            });
        },
        getRefId:function(){
            var url = location.href,
                hasRefId = /[#\?&]refid=(\d+)/.exec(url);
            if(hasRefId&&hasRefId[1]){
                return "&refid="+hasRefId[1];
            }else{
                return "";
            }
        }
    };
}(jQuery));
