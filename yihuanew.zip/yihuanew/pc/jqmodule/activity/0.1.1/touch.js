/**
 * @desc:$
 * @author: HanlibaLi
 * @mail: lxq10107@ly.com
 * @createTime: 2015/3/5 14:33
 */
/* global $ */
var Activity;
var tcApp = {
    url: "http://shouji.17u.cn/internal/holiday/details/{{lineId}}/{{activityId}}/{{cycleId}}",
    checkUrl: "http://www.ly.com/dujia/AjaxHelper/PrickGoldFingerHandler.ashx?action=GETENCRYPTIONURL&isHot=2&sub=0&lineid={lineId}&actId={activityId}&actSchedule={CycleId}",
    sceneryUrl: "http://www.ly.com/dujia/AjaxHelper/SingleProductHandler.ashx?action=GetSingleProductActUrl&id={LineId}&actId={ActivityId}&periodId={CycleId}",
    version: 7.1,
    /**
     * @desc 检测是否是有效的app,版本>=7.1
     * @returns {boolean}
     */
    check: function(){
        var ua = navigator.userAgent,
            isApp = /TcTravel\/(\d+\.\d+\.\d+)/.exec(ua);
        if(isApp&&isApp[1]){
            var version = isApp[1];
            if(parseFloat(version)>=this.version){
                return true;
            }
        }
    },
    /**
     * @desc 传入一个节点
     * @param {HTMLElement} el
     */
    go: function(el){
        if(! (el &&this.check())){
            return;
        }
        var url = this.url,
            lineId = el.getAttribute("data-lineId"),
            actId = el.getAttribute("data-activityId"),
            cycleId = el.getAttribute("data-cycleId"),
            data = {};
        if(!lineId&&actId&&cycleId){
            return;
        }
        data = {
            lineId: lineId,
            activityId: actId,
            cycleId:cycleId
        };
        return url.replace(/{{(\w+)}}/g,function($0,$1){
            return data[$1];
        });
    },
    addStyle: function(){
        var link = document.createElement("style");
        link.type = "text/css";
        link.innerHTML = ".go-top{display:none;position:fixed;bottom: 20px; right: 20px;width:40px;height:40px;} .go-top img{width:100%;height:100%;}";
        document.getElementsByTagName("head")[0].appendChild(link);
    },
    goTop: function(cfg){
        if(cfg === false){
            return;
        }
        var defaultCfg = {
            cls: "go-top",
            top: 300,
            img: "http://img1.40017.cn/cn/v/chuochuonew/gotop.png"
        };
        var thisCfg = $.extend(defaultCfg,cfg);
        var goTopEl = $(".J_GoTop");
        if(goTopEl.length === 0){
            this.addStyle();
            $("body").append('<span class="J_GoTop '+ thisCfg.cls +'"><img src="'+thisCfg.img+'" /></span>');
            goTopEl = $(".J_GoTop");
        }else{
            return;
        }
        goTopEl.on("click",function(){
            window.scrollTo(0,0);
            goTopEl.hide();
        });
        $(window).on("scroll",function(){
            var cScrollTop = document.body.scrollTop;
            if(cScrollTop > thisCfg.top){
                goTopEl.show();
            }else if(cScrollTop < thisCfg.top){
                goTopEl.hide();
            }
        });
    },
    encryptScenery: function(el,callback){
        var self = this;
        var checkUrl = self.checkUrl,
            url = checkUrl.replace(/{(\w+)}/g,function($0,$1){
                var attr = el.getAttribute("data-"+$1);
                if(!attr){
                    console.log($1+"对应的值不存在!");
                }
                return attr||"";
            });
        $.ajax({
            url: url,
            dataType: "jsonp",
            success: function(data){
                if(data){
                    var extraStr = self.extraStr||"",
                        //http://m.ly.com/dujia/tours/233763.html
                        //http://m.ly.com/dujia/scenerydetail_233765.html
                        _url = data.url.replace(/tours\/(\d+)/g,"scenerydetail_$1");
                    var url = _url+"&wvc1=1"+extraStr+self.getRefId();
                    callback.call(self);
                    window.location.href= url;
                }
            }
        });
    },
    encrypt: function(el,isLogin,callback,liveFired){
        var self = this,
            ret = Activity.cfg.checkScenery && Activity.cfg.checkScenery.call(Activity,el,liveFired);
        if(ret){
            self.encryptScenery(el,callback,liveFired);
            return;
        }
        var checkUrl = self.checkUrl,
            url = checkUrl.replace(/{(\w+)}/g,function($0,$1){
                var attr = el.getAttribute("data-"+$1);
                if(!attr){
                    console.log($1+"对应的值不存在!");
                }
                return attr||"";
            });
        $.ajax({
            url: url,
            dataType: "jsonp",
            success: function(data){
                if(data){
                    var extraStr = isLogin?"&memberId="+Activity.memberId:"";
                    var url = self.go(el)||data.url+"&wvc1=1"+extraStr+self.getRefId();
                    callback.call(self);
                    window.location.href= url;
                }
            }
        });
    },

    getRefId:function(){
        var url = location.href,
            hasRefId = /[#\?&]refid=(\d+)/i.exec(url);
        if(hasRefId&&hasRefId[1]){
            return "&refid="+hasRefId[1];
        }else{
            return "";
        }
    },
    getDebug: function(){
        var self = this;
        if(self.isDebug == null){
            self.isDebug = location.href.indexOf("__debug__")>-1;
            return self.isDebug;
        }else{
            return self.isDebug;
        }
    }
};
Activity = {
    cfg:{
        activityId: 0,
        cycleList: [],
        IsSellOut: 0,
        prefix: "__act__",
        dataUrl:"http://www.ly.com/dujia/AjaxHelper/PrickGoldFingerHandler.ashx?action=GETTARENTORESOURSELIST&pageindex=1&pagesize=200&platForm=3&lists=",
        urlTmpl: "{dataUrl}{activityId}&pid={cycleId}&IsSellOut={IsSellOut}",
        el: ".prolist",
        index: 0,
        login: false,
        memberId: "tcwvmid",
        host: "http://www.ly.com",
        beforeRender: function(data){
            if(Activity._cfg.filter){
                return this.filterData(data);
            }else{
                this.data = data;
                return data.data;
            }
        },
        afterRender: function(){

        },
        checkScenery: function(el,liveFired){
            if(liveFired && liveFired.getAttribute("data-scenery")){
                return true;
            }
        }
    },
    localData: {},
    data: {},
    filterData: function(data){
        var cfg = this._cfg,
            el = $(cfg.el),
            newData = {};
        var filterRule = [],
            filterElRule = {};
        el.each(function(i,n){
            var filterStr = n.getAttribute("data-filter");
            if(filterStr){
                if(!filterRule){
                    filterRule = [];
                }
                //如果不包含，则放入数组
                if(!~filterRule.indexOf(filterStr)){
                    filterRule.push(filterStr);
                }
                var _ruleItem = filterElRule[filterStr];
                if(!_ruleItem){
                    _ruleItem = [];
                }
                _ruleItem.push(n);
                filterElRule[filterStr] = _ruleItem;
            }
        });
        if(filterRule.length === 0){
            return data.data;
        }
        this.filterElRule = filterElRule;
        var filterRuleItem = filterRule;
        if(!filterRuleItem){
            console.log("对应容器的规则不存在!");
            return;
        }
        for(var i = 0, len = data.data.length -1; i<=len; i++){
            var item = data.data[i];
            for(var n = 0, nLen = filterRuleItem.length -1; n<=nLen; n++){
                var filterItem = filterRuleItem[n],
                    filterObjItem = this.unparam(filterItem);
                if(filterObjItem){
                    var flag = true;
                    for(var x in filterObjItem){
                        if(!filterObjItem.hasOwnProperty(x)){
                            continue;
                        }
                        if(item[x] != filterObjItem[x]){
                            flag = false;
                            break;
                        }
                    }
                    if(flag){
                        if(!newData[filterItem]){
                            newData[filterItem] = [];
                        }
                        newData[filterItem].push(item);
                        break;
                    }
                }else{
                    alert("filter表达式不存在!");
                }
            }
        }
        return newData;
    },
    unparam: function(str, sep, eq) {
        if (typeof str !== 'string' || !(str = $.trim(str))) {
            return {};
        }
        sep = sep || "&";
        eq = eq || "=";
        var ret = {},
            eqIndex,
            pairs = str.split(sep),
            key, val,
            i = 0,
            len = pairs.length;

        for (; i < len; ++i) {
            eqIndex = pairs[i].indexOf(eq);
            if (eqIndex === -1) {
                key = pairs[i];
                val = undefined;
            } else {
                key = pairs[i].substring(0, eqIndex);
                val = pairs[i].substring(eqIndex + 1);
            }
            if (key in ret) {
                if (typeof (ret[key]) === "object") {
                    ret[key].push(val);
                } else {
                    ret[key] = [ret[key], val];
                }
            } else {
                ret[key] = val;
            }
        }
        return ret;
    },
    init: function(cfg){
        var self = this,
            defaultCfg = self.cfg;
        var _cfg = self._cfg = $.extend(defaultCfg,cfg),
            param = _cfg.param;
        if(!param){
            console.log("param不存在");
            return;
        }
        if(!self.isInitEvent){
            self.localData = self.getLocalInst();
        }
        var paramList = self.getParamData(param);
        if(paramList.length > 0){
            self.getOneData(paramList,function(){});
        }
        if(self.isInitEvent){
            return;
        }
        self.isInitEvent = true;
        if(!_cfg.clickEvent){
            self.initEvent();
        }else{
            _cfg.clickEvent.call(self,$(_cfg.el));
        }
        self.initSaveEvent();
        tcApp.goTop(cfg.goTop);
    },
    getParamData: function(param){
        if(!(param &&$.isArray(param))){
            console.log("请求接口所需参数不存在!");
            return;
        }
        var paramList = [];
        for(var x = 0, len = param.length -1; x<=len; x++){
            var paramItem = param[x];
            if(typeof (paramItem) === "string"||typeof (paramItem) === "number"){
        		paramList = paramList.concat(param);
            	break;
            }
            for(var i in paramItem){
                if(!paramItem.hasOwnProperty(i)){
                    continue;
                }
                var item = paramItem[i];
                if(typeof item === "object"){
                    for(var n = 0; n<=item.length -1; n++){
                        paramList.push([i,item[n]]);
                    }
                }
            }
        }
        return paramList;
    },
    getOneData: function(paramList,callback){
        var self = this;
        if(paramList.length){
            var paramItem = paramList.shift();
            var thisCfg = $.extend({},self._cfg);
            thisCfg.activityId = paramItem[0];
            thisCfg.cycleId = paramItem[1];
            self.getData(thisCfg,function(data){
                if(data){
                    var arr = data.data||data,
                        selfArr = self.data.data||[];
                    self.data["data"] = selfArr.concat(arr);
                }
                self.getOneData(paramList,callback);
            });
        }else{
            var data = self.data,
                retData = self._cfg.beforeRender && self._cfg.beforeRender.call(self,data);
            self.render(retData);
            var afterRenderFunc = self._cfg.afterRender && self._cfg.afterRender.call(self,retData);
            if(afterRenderFunc !== false){
                function _callback(data,localData){
                    if(data){
                        if(!window.__click__){
                            if(localData.scrollTop){
                                window.scrollTo(0,localData.scrollTop);
                            }
                        }
                    }
                }
                _callback(retData,self.localData);
                self.imgLazyLoad();
                callback && callback.call(this);
            }
        }
    },
    getLocalInst: function(){
        var localDataStr = localStorage.getItem(this._cfg.prefix+"localData")||"{}",
            localData = JSON.parse(localDataStr);
        return localData;
    },
    initEvent: function(){
        var me = this,
            cfg = me.cfg,
            context = $(cfg.el);

        $(context).on("click","a",function(e){
            if(me.isClicking) {
                return;
            }
            if($(this).hasClass("disable")){
                return false;
            }
            me.isClicking = true;
            tcApp.encrypt(this,cfg.login, function(){
                me.isClicking = false;
            }, e.liveFired);
            e.preventDefault();
        });
    },
    render: function(data,index){
        var self = this;
        if(self._cfg.filter){
            var ruleItem = self.filterElRule;
            for(var x in ruleItem){
                self.renderHTML(data[x]||{},$(ruleItem[x]));
            }
        }else{
            self.renderHTML(data,$(self._cfg.el));
        }
    },
    renderHTML: function(data,context,tmplStr){
        if(!tmplStr){
            tmplStr = context.attr("data-tmpl");
        }
        if(!tmplStr){
            alert("没有配置data-tmpl");
            return;
        }
        if(context.attr("data-rendered")){
            return;
        }

        var tmpl = $(tmplStr).html();
        var tpl = window.doT.template(tmpl);
        var html = tpl(data);
        context.empty().append(html);
        if(html!==''){
            context.attr("data-rendered","true");
        }
    },
    getData: function(cfg,callback){
        var self = this;
        var url = cfg.urlTmpl.replace(/{(\w+)}/g,function($0,$1){
            if(cfg[$1] === undefined){
                console.log("url对应的"+$1+"参数不存在!");
            }
            return cfg[$1]===undefined?"":cfg[$1];
        });
        $.ajax({
            url: url,
            dataType: "jsonp",
            jsonpCallback: "jsonp"+cfg.cycleId,
            success: function(data){
                self.setLocalData(url,data);
                callback && callback.call(self,data);
            },
            error: function(err){
                if(err){
                    console.error("接口有误:"+url);
                }
            }
        });
    },
    getLocalData: function(key){
        if(typeof key === "string"){
            return this.localData && this.localData[key]||"";
        }
    },
    setLocalData: function(key,value){
        var _value = value;
        if(typeof value !== "string"){
            try{
                if(value.status && value.status !== 100){
                    return;
                }
                _value = JSON.stringify(value.data||value);
            }catch(e){
                console.log("数据解析失败!");
                console.log(e);
                return;
            }
        }
        this.localData[key] = _value;
    },
    setImageSize: function (url, size) {

        if (!url) {
            return null;
        }
        var defaultSize = "_600x300_00";
        if(size && size.indexOf("_") === -1){
            size = "_"+size+"_00";
        }
        var reg = /_[0-9]{2,3}x[0-9]{2,3}_[0-9]?[0-9]/;
        var regSize = /_[0-9]{2,3}x[0-9]{2,3}_[0-9]?[0-9]$/;
        if (reg.test(url) && regSize.test(size)) {
            return url.replace(reg, size);
        }

        if (reg.test(url)) {
            return url;
        }

        if (url.indexOf("upload.17u.com") > -1) {
            return url;
        } else if (!reg.test(url) && !/(scenery)/.test(url)) {//含有scenery（国际景点）不替换
            return url.replace(/\.\w+$/,function($0){
                return (size || defaultSize)+$0;
            });
        }else{
            return url;
        }
    },
    imgLazyLoad: function(){
        var self = this,
            cfg = self.cfg,
            parent = $(cfg.el).parent();
        if (this.isInit) {
            var imgList = parent.find("img").not("[data-img-loaded]");
            $(window).trigger("addElements",imgList);
        } else {
            parent.find("img").not("[data-img-loaded]").lazyload({
                "data_attribute": "img",
                css: {
                    opacity: 0
                },
                effect: 'fadeIn'
            });
            this.isInit = true;
        }
    },
    initSaveEvent: function(){
        var self = this;
        window.onunload = function(){
            var _localData = $.extend(Activity.localData,{
                scrollTop: document.body.scrollTop
            });
            localStorage.setItem(self._cfg.prefix+"localData",JSON.stringify(_localData));
        };
    }
};
