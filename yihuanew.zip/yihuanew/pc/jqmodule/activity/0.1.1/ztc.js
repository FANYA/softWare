(function($){
    String.prototype.Trim = function() {
        return this.replace(/^\s+/g, "").replace(/\s+$/g, "")
    };
    var strHost;
    strHost = getCookieDomain();

    function getCookieDomain() {
        if (location.hostname.match(/^(\d+\.\d+\.\d+\.\d+)|(localhost)$/)) {
            return location.hostname
        } else {
            return /.*(\..*\..*)$/.exec(location.hostname)[1]
        }
    }

    function dumpRefid(c) {
        var g = getRefid();
        var f = encodeURIComponent(document.referrer);
        if (document.referrer.indexOf("http://www.hao123.com") > -1) {
            g = "12034002"
        }
        var m = "RefId=" + g,
            d = "CNSEInfo",
            a = new Date();
        var e = AnalyseSearchEngine();
        if (!c && e[1] === "gb2312") {
            var k = document.createElement("script");
            k.src = "http://www" + strHost +
                "/AjaxHelper/Gb2312ToUtf8.ashx?words=" + e[2] +
                "&callback=reDumpRefid";
            document.getElementsByTagName("head")[0].appendChild(k);
            return
        }
        e[0] = encodeURIComponent(e[0]);
        e[2] = c ? c : e[2];
        if ((f.indexOf(".17u.com") > -1) || (f.indexOf(".17u.cn") > -1) || (f.indexOf(
                ".ly.com") > -1) || (f.indexOf(".LY.com") > -1) || (f.indexOf(
                ".tongcheng.com") > -1) || (f.indexOf("localhost") > -1) || (f.indexOf(
                "192.168.") > -1) || (f.indexOf("172.16.") > -1) || f === "") {
            e[0] = encodeURIComponent(fish.cookie.get("CNSEInfo", "SEFrom"));
            e[2] = encodeURIComponent(fish.cookie.get("CNSEInfo", "SEKeyWords"));
            f = encodeURIComponent(fish.cookie.get("CNSEInfo", "RefUrl"))
        }
        f = f == undefined ? "" : f;
        f = f == "undefined" ? "" : f;
        e[0] = e[0] == undefined ? "" : e[0];
        e[0] = e[0] == "undefined" ? "" : e[0];
        e[2] = e[2] == undefined ? "" : e[2];
        e[2] = e[2] == "undefined" ? "" : e[2];
        var i = "SEFrom=" + e[0];
        var j = "SEKeyWords=" + e[2];
        var h = "RefUrl=" + f;
        var n = m + "&" + i + "&" + j + "&" + h;
        var b = 0;
        var l = m + "&" + i + "&" + j;
        if (g + "" === "6076168") {
            b = 1
        }
        fish.cookie.set({
            name: d,
            value: n,
            path: "/",
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: d,
            value: n,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: d,
            value: n,
            days: -1,
            path: "/",
            encode: false
        });
        fish.cookie.set({
            name: d,
            value: n,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "17uCNRefId",
            value: l,
            path: "/",
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "17uCNRefId",
            value: l,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "17uCNRefId",
            value: l,
            days: -1,
            path: "/",
            encode: false
        });
        fish.cookie.set({
            name: "17uCNRefId",
            value: l,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "TicketSEInfo",
            value: l,
            path: "/",
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "TicketSEInfo",
            value: l,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        });
        fish.cookie.set({
            name: "TicketSEInfo",
            value: l,
            days: -1,
            path: "/",
            encode: false
        });
        fish.cookie.set({
            name: "TicketSEInfo",
            value: l,
            path: "/",
            domain: strHost,
            encode: false,
            days: b
        })
    }

    function reDumpRefid(a) {
        if (a && a.words && a.words !== "") {
            dumpRefid(a.words)
        } else {
            dumpRefid("")
        }
    }

    function getRefid() {
        var f = window.location.href.toLowerCase(),
            d, b;
        d = fish.cookie.get("CNSEInfo", "RefId");
        var a = f.indexOf("#");
        var c = f.indexOf("?");
        if (a > -1) {
            b = f.substring(a + 1);
            var e = findParam(b, "refid");
            if (e !== "" && e !== "undefined" && e != undefined) {
                d = e
            }
        }
        if (c > -1) {
            if (a > -1 && c < a) {
                b = f.substring(c + 1, a)
            } else {
                b = f.substring(c + 1)
            }
            var e = findParam(b, "refid");
            if (e !== "" && e !== "undefined" && e != undefined) {
                d = e
            }
        }
        d = d == undefined ? "0" : d;
        d = d == "undefined" ? "0" : d;
        return d === "" ? "0" : d
    }

    function getMemberId() {
        var a = fish.cookie.get("CNMember", "MemberId");
        a = a == undefined ? "0" : a;
        a = a == "undefined" ? "0" : a;
        return a === "" ? "0" : a
    }

    function findParam(c, a) {
        var d = c.split(/&|#/g);
        for (var b = 0; b < d.length; b++) {
            if (d[b].substring(0, a.length + 1) == (a + "=")) {
                return d[b].substring(a.length + 1)
            }
        }
        return ""
    }

    function AnalyseSearchEngine() {
        var c = new Array("", "", "");
        if (document.referrer && document.referrer != "") {
            var d = document.referrer;
            var e, b, f;
            if (d.match(new RegExp("baidu\\."))) {
                e = "baidu";
                b = "gb2312";
                if (d.match(new RegExp("(\\?|\\&)(wd|word)\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)(wd|word)\\=([^\\&]+)"));
                    f = a[3];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=utf\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("google\\."))) {
                e = "google";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(gb2312)|(gb)"))) {
                        b = "gb2312"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("yahoo\\."))) {
                e = "yahoo";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)p\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)p\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ei)\\=(GBK|gbk)"))) {
                        b = "gbk"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("bing\\."))) {
                e = "bing";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2]
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("soso\\."))) {
                e = "soso";
                b = "gb2312";
                if (d.match(new RegExp("(\\?|\\&)w\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)w\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("sogou\\."))) {
                e = "sogou";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)query\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)query\\=([^\\&]+)"));
                    f = a[2]
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("iask\\."))) {
                e = "iask";
                b = "gb2312";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2]
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("youdao\\."))) {
                e = "youdao";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(gb2312)|(gb)"))) {
                        b = "gb2312"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("so\\.360"))) {
                e = "so.360";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("www\\.so\\."))) {
                e = "so.com";
                b = "gb2312";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("jike\\."))) {
                e = "jike";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("panguso\\."))) {
                e = "panguso";
                b = "utf-8";
                if (d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)q\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
            if (d.match(new RegExp("zhongsou\\."))) {
                e = "zhongsou";
                b = "gb231";
                if (d.match(new RegExp("(\\?|\\&)w\\=([^\\&]+)"))) {
                    var a = d.match(new RegExp("(\\?|\\&)w\\=([^\\&]+)"));
                    f = a[2];
                    if (d.match(new RegExp("(\\?|\\&)(ie)\\=(UTF|utf)\\-8"))) {
                        b = "utf-8"
                    }
                }
                c[0] = e;
                c[1] = b;
                c[2] = f;
                return c
            }
        }
        return c
    }
    window.reDumpRefid = reDumpRefid;
    window.getRefid = getRefid;
    window.getMemberId = getMemberId;
    window.dumpRefid = dumpRefid;
    dumpRefid();
    fish.dom("span.top_login02") && (fish.dom("span.top_login02").innerHTML =
            "<a class='sgin_text loginText ie6Text' id='loginHref' href='http://passport" +
            strHost + "/' nhref='http://passport" + strHost +
            "/?pageurl={backurl}' onclick=\"this.href = this.getAttribute('nhref').replace('{backurl}', encodeURIComponent(window.location.href))\" rel='nofollow'>登录</a>"
    );
    fish.dom("span.top_login03") && (fish.dom("span.top_login03").innerHTML =
        "<a class='sgin_text ie6Text'  nhref='http://passport" + strHost +
        "/register/index/?pageurl={backurl}' onclick=\"this.href = this.getAttribute('nhref').replace('{backurl}', encodeURIComponent(window.location.href))\" href='http://passport" +
        strHost + "/register/index/' rel='nofollow'>注册</a>");
    if (fish.cookie.get("us")) {
        var username = fish.cookie.get("us", "nickName"),
            cnUserId = fish.cookie.get("us", "userid"),
            data = {
                state: 100
            };
        if (cnUserId != null) {
            loginState = data
        } else {
            loginState = {
                state: 200
            }
        }
        if (username != "") {
            $("#zhuantiHeadNew").html(
                "<a class='loadName' rel='nofollow' href='http://member" +
                strHost + "'>" + username +
                "</a><span class='headR_name'>，您好</span><a rel='nofollow' href='/AjaxHelper/TopLoginHandler.aspx?action=exitnew'>[退出]</a>"
            );
            loginState = data
        } else {
            username = fish.cookie.get("passport_login_state", "partner_loginname");
            if (username != "" && username != null) {
                $("#zhuantiHeadNew").html(
                    "<a class='loadName' rel='nofollow' href='http://member" +
                    strHost + "'>" + username +
                    "</a><span class='headR_name'>，您好</span><a rel='nofollow' href='/AjaxHelper/TopLoginHandler.aspx?action=exitnew'>[退出]</a>"
                )
            }
        }
    }
}(jQuery));

