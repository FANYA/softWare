### DIALOG组件
 * 来自artDialog
 * 文档地址: http://aui.github.io/artDialog/doc/index.html